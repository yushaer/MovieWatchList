# MovieWatchList
This is the repository is for my movies watch list web app you can view the live demo at https://pro-movie-watchlist.netlify.app/
