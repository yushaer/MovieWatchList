import { combineReducers } from "redux";
import movies from './movie';
import user from './user';
export default combineReducers({movies,user})